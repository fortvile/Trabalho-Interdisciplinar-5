# semaforo2.py (atualizado para receber tempos S1 e S2)
import socket
import time

SERVER_HOST = "localhost"
SERVER_PORT = 5000

def semaforo2():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            print(f"[S2] Conectando em {SERVER_HOST}:{SERVER_PORT} ...")
            s.connect((SERVER_HOST, SERVER_PORT))
            print("[S2] Conectado ao servidor.")

            while True:
                data = s.recv(1024)
                if not data:
                    print("[S2] Conexão fechada pelo servidor.")
                    break

                text = data.decode().strip()
                # formato "tempoS1,tempoS2"
                parts = text.split(",")
                if len(parts) >= 2:
                    try:
                        tempo_verde_s1 = int(parts[0])
                        tempo_verde_s2 = int(parts[1])
                    except ValueError:
                        print(f"[S2] Mensagem com formato inválido (valores não inteiros): '{text}'")
                        continue
                else:
                    print(f"[S2] Mensagem inválida recebida: '{text}'")
                    continue

                # Regra de não-conflito: enquanto S1 está verde, S2 fica vermelho
                print(f"[S2] Semáforo 1 VERDE {tempo_verde_s1}s → S2 fica VERMELHO")
                time.sleep(tempo_verde_s1)

                # Agora S2 abre pelo tempo calculado para S2
                print(f"[S2] AGORA S2 abre por {tempo_verde_s2}s")
                # Simula verde
                time.sleep(tempo_verde_s2)
                # Simula amarelo fixo 3s
                print("[S2] S2 amarelo (3s)")
                time.sleep(3)
                # Após amarelo, volta para vermelho e aguarda próxima mensagem
                print("[S2] S2 voltou para VERMELHO")
        except Exception as e:
            print(f"[S2] Erro de conexão/execução: {e}. Tentando reconectar em 3s...")
            try:
                s.close()
            except:
                pass
            time.sleep(3)

if __name__ == "__main__":
    semaforo2()
